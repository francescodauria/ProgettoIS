/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientcalculatorwebservice_lab6;

/**
 *
 * @author Francesco D'Auria
 */
public class ClientCalculatorWebService_Lab6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println(hello("Francesco"));
        System.out.println(sum(3,5));
    }

    private static int sum(int a, int b) {
        calculator.CalculatorWebService_Service service = new calculator.CalculatorWebService_Service();
        calculator.CalculatorWebService port = service.getCalculatorWebServicePort();
        return port.sum(a, b);
    }

    private static String hello(java.lang.String name) {
        calculator.CalculatorWebService_Service service = new calculator.CalculatorWebService_Service();
        calculator.CalculatorWebService port = service.getCalculatorWebServicePort();
        return port.hello(name);
    }
    
}
